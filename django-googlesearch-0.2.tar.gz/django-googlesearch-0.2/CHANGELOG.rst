Changelog
=========

0.2
---
#. Django 1.6 compatibility.

0.1.2
-----
#. Refer to correct template tag in help text. Thanks grafyte.

0.1
---
#. Refactor to use a linked custom search engine as described at http://www.google.com/cse/docs/cref.html.

0.0.6
-----
#. Packaging and test setup cleanup.

0.0.5
-----
#. Refactor to not use django-preferences.
#. Documentation.

