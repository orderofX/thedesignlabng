import unittest


class TestCase(unittest.TestCase):
    def test_something(self):
        raise NotImplementedError('Test not implemented. Bad developer!')
