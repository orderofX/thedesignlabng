
django.jQuery(function($) {
	'use strict';

	django.cascade.ProceedButtonPlugin = ring.create(eval(django.cascade.ring_plugin_bases.ProceedButtonPlugin), {});
});
